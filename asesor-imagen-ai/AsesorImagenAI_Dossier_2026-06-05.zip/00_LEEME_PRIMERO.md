# 📦 Dossier — Asesor Imagen AI

**Generado:** 2026-06-05
**Para:** Colaborador externo de Juan Camilo Gil
**Proyecto:** Asesor Imagen AI (flagship activo de la Agencia)

---

## 🎯 Estado actual (snapshot)

- **Sprint:** 0.5 — Worker Integration & Real API Calls (en curso)
- **Sprints completados:** 0.1 ✅ · 0.2 ✅ · 0.3 ✅ (161 tests, 82% cov, 0 hallazgos CRÍTICOS)
- **Decisiones D1-D5:** ✅ APROBADAS (2026-05-18)
- **Diseño:** ✅ Aether Luxe — `DESIGN_HANDOFF_S01-S11` completo
- **Backend:** 3 buckets storage + Dockerfile + railway.toml listos
- **Flutter:** Demo mode resiliente (env + supabase guard)
- **Revenue model:** ✅ GO — Opción F (+$233K/mes margen a 1M MAU)

### Pendientes inmediatos
- Deploy a Railway (credenciales reales pendientes de Juan Camilo)
- Commit y push de ~14 archivos modificados
- Migración modelos Claude → Opus 4.8 antes del **15 jun 2026** (sonnet-4 / opus-4 se retiran)
- Revisar Supabase breaking changes (Postgres 15→17, pg_graphql introspection OFF — **15 jun**)

### Commits relevantes recientes
```
d9f0d3a  chore(mvp): backend Sprint 0.5 — 3 buckets + Dockerfile + railway.toml
5b3ac87  fix(flutter): Resilient demo mode — Env, DioClient, Supabase guard
d475408  design(erik): S06 Soft Cap UI + DESIGN_HANDOFF_S01-S11 completo
06800f7  Fix 4 Flutter issues: deps, imports, build_runner, theme integration
```

---

## 📂 Estructura del paquete

### `01_Vault_Project/` — Documentación canónica del proyecto (Obsidian vault)
Arquitectura, schemas, checklist de ejecución, resumen ejecutivo, quickstart e índice maestro.
**Empieza aquí:** `ASESOR_IMAGEN_AI_INDEX.md` y `ASESOR_IMAGEN_AI_RESUMEN_EJECUTIVO.md`

### `02_Sprint_Docs/` — Toda la operación del sprint
- **Plan maestro:** `MASTER_PLAN.md`, `MASTER_PROMPT.md`, `ROADMAP_7_DIAS.md`, `GANTT_SPRINT_PLAN.md`
- **Sprint tracker:** `SPRINT_TRACKER.md` (estado live)
- **Decisiones:** `DECISIONES_APROBADAS.md`, `DECISION_AUDIT_D1_D5.md`, `DECISIONES_CRITICAS_UX.md`
- **ADRs:** `ADR-006-revenue-model.md`, `ADR_007_RATE_LIMITING.md`
- **Workers (Sprint 0.5):** `WORKERS_IMPLEMENTATION.md`, `WORKERS_INTEGRATION_GUIDE.md`
- **Seguridad/Producción:** `SECURITY_ARCHITECTURE.md`, `PRODUCTION_SLOS.md`, `RLS_VERIFICATION.md`, `LUA_SCRIPTS_VALIDATED.md`
- **Económico:** `COST_MODEL_PATH_A.md`, `MARGIN_AUDIT_FINAL.md`, `PRICING_STRATEGY.md`, `SCALING_STRATEGY_10X.md`
- **UX / Diseño:** `UX_SCREENS_PLAN.md`, `DESIGN_HANDOFF_S01-S11.md`, `ERIK_SPRINT_TRACKER.md`, `COPY_SOFT_CAP_APPROVED.md`, `MESSAGING_STRATEGY_FINAL.md`, carpetas `design-system/` y `mockups/`
- **Intel:** `INTEL_COMPETIDORES_2026.md`, `FLUX_SCHNELL_QUALITY_AUDIT.md`
- **Para Juan Camilo:** `JUAN_CAMILO_ACCIONES_CRITICAS.md`, `JUAN_CAMILO_RESUMEN_EJECUCION.md`, `IMMEDIATE_NEXT_STEPS_FOR_JUAN_CAMILO.md`
- **Triggers por equipo:** `TRIGGER_SASHA_INFRASTRUCTURE.md`, `TRIGGER_BROOK_FLUTTER_FIXES.md`, `TRIGGER_ANTIGRAVITY_SPRINT_0_4.md`
- **Junta:** `JUNTA_SABADO_2026-05-02.md`

### `03_Guides_Deployment/` — Guías operativas
- `README.md` — entrada al repo de código
- `DESIGN.md` — sistema de diseño Aether Luxe
- `RAILWAY_DEPLOYMENT_GUIDE.md` — paso a paso de deploy
- `EJECUCIÓN_SPRINT_0_5.md` — cómo correr el sprint actual
- `CREDENCIALES_SUPABASE_SETUP.md` — setup Supabase (placeholders, sin secretos)
- `railway.toml` — config de servicio

---

## 🚫 Lo que NO está incluido (intencional)

- **Código fuente** (`backend/`, `frontend/`) — está en el repo Git, pesado y muta a diario
- **`.env` y credenciales reales** — riesgo de fuga
- **`RAILWAY_ENV_VARS.txt`** — contiene placeholders de secretos

Si el colaborador necesita el código, lo correcto es darle acceso al repo Git directamente.

---

## ✉️ Contacto

- **Owner del proyecto:** Juan Camilo Gil (Gerente Comercial)
- **Tech lead:** Sasha (Backend) + Brook (Flutter) + Erik (Design), coordinados por Jarvis (PM)
